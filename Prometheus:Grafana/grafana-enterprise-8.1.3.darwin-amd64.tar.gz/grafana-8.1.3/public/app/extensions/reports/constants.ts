const defaultReportLogo = '/public/img/grafana_icon.svg';
const defaultEmailLogo = 'https://grafana.com/static/assets/img/grafana_logo_lockup_ltbg.png';

export { defaultReportLogo, defaultEmailLogo };
